<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Hire Gree | Services</title>

    <!-- SEO Meta Tags -->
    <meta name="description" content="Hire Gree - Services">
   
    <!-- Viewport -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon and Touch Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/17.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/17.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/17.png">
    <link rel="manifest" href="assets/favicon/site.webmanifest">
    <link rel="mask-icon" href="assets/favicon/safari-pinned-tab.svg" color="#6366f1">
    <link rel="shortcut icon" href="assets/img/17.png">
    <meta name="msapplication-TileColor" content="#080032">
    <meta name="msapplication-config" content="assets/favicon/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">

    <!-- Vendor Styles -->
    <link rel="stylesheet" media="screen" href="assets/vendor/boxicons/css/boxicons.min.css" />

    <!-- Main Theme Styles + Bootstrap -->
    <link rel="stylesheet" media="screen" href="assets/css/theme.min.css">

    <!-- Page loading styles -->
    <style>
        .page-loading {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 100%;
            -webkit-transition: all .4s .2s ease-in-out;
            transition: all .4s .2s ease-in-out;
            background-color: #fff;
            opacity: 0;
            visibility: hidden;
            z-index: 9999;
        }

        .dark-mode .page-loading {
            background-color: #0b0f19;
        }

        .page-loading.active {
            opacity: 1;
            visibility: visible;
        }

        .page-loading-inner {
            position: absolute;
            top: 50%;
            left: 0;
            width: 100%;
            text-align: center;
            -webkit-transform: translateY(-50%);
            transform: translateY(-50%);
            -webkit-transition: opacity .2s ease-in-out;
            transition: opacity .2s ease-in-out;
            opacity: 0;
        }

        .page-loading.active>.page-loading-inner {
            opacity: 1;
        }

        .page-loading-inner>span {
            display: block;
            font-size: 1rem;
            font-weight: normal;
            color: #9397ad;
        }

        .dark-mode .page-loading-inner>span {
            color: #fff;
            opacity: .6;
        }

        .page-spinner {
            display: inline-block;
            width: 2.75rem;
            height: 2.75rem;
            margin-bottom: .75rem;
            vertical-align: text-bottom;
            border: .15em solid #b4b7c9;
            border-right-color: transparent;
            border-radius: 50%;
            -webkit-animation: spinner .75s linear infinite;
            animation: spinner .75s linear infinite;
        }

        .dark-mode .page-spinner {
            border-color: rgba(255, 255, 255, .4);
            border-right-color: transparent;
        }

        @-webkit-keyframes spinner {
            100% {
                -webkit-transform: rotate(360deg);
                transform: rotate(360deg);
            }
        }

        @keyframes spinner {
            100% {
                -webkit-transform: rotate(360deg);
                transform: rotate(360deg);
            }
        }
    </style>

    <!-- Theme mode -->
    <script>
        let mode = window.localStorage.getItem('mode'),
            root = document.getElementsByTagName('html')[0];
        if (mode !== null && mode === 'dark') {
            root.classList.add('dark-mode');
        } else {
            root.classList.remove('dark-mode');
        }
    </script>

    <!-- Page loading scripts -->
    <script>
        (function() {
            window.onload = function() {
                const preloader = document.querySelector('.page-loading');
                preloader.classList.remove('active');
                setTimeout(function() {
                    preloader.remove();
                }, 1000);
            };
        })();
    </script>

    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-WKV3GT5');
    </script>
</head>


<!-- Body -->

<body>

    <!-- Google Tag Manager (noscript)-->
    <noscript>
      <iframe src="//www.googletagmanager.com/ns.html?id=GTM-WKV3GT5" height="0" width="0" style="display: none; visibility: hidden;"></iframe>
    </noscript>

    <!-- Page loading spinner -->
    <div class="page-loading active">
        <div class="page-loading-inner">
            <div class="page-spinner"></div><span>Loading...</span>
        </div>
    </div>


    <!-- Page wrapper for sticky footer -->
    <!-- Wraps everything except footer to push footer to the bottom of the page if there is little content -->
    <main class="page-wrapper">


        <!-- Navbar -->
        <!-- Remove "navbar-sticky" class to make navigation bar scrollable with the page -->
        <header class="header navbar navbar-expand-lg bg-light navbar-sticky">
            <div class="container px-3">
                <a href="index.html" class="navbar-brand pe-3">
            <img src="assets/img/17.png" width="47" alt="Silicon">
            Gree
          </a>
                <div id="navbarNav" class="offcanvas offcanvas-end">
                    <div class="offcanvas-header border-bottom">
                        <h5 class="offcanvas-title">Menu</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle active" data-bs-toggle="dropdown" aria-current="page">About us</a>
                                <div class="dropdown-menu p-0">
                                    <div class="d-lg-flex">
                                        <div class="">
                                        </div>
                                        <div class="mega-dropdown-column pt-lg-3 pb-lg-4">
                                            <ul class="list-unstyled mb-0">
                                                <li><a href="index.html" class="dropdown-item">Our Histoyry</a></li>
                                                <li><a href="landing-mobile-app-showcase-v1.html" class="dropdown-item">Our Services</a></li>
                                                <li><a href="landing-mobile-app-showcase-v2.html" class="dropdown-item">Our Mission</a></li>
                                                <li><a href="landing-product.html" class="dropdown-item d-flex align-items-center">Success History</a></li>
                                               
                                            </ul>
                                        </div>
                                        <div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="" class="nav-link">Services</a>
                                <div class="">
                                    <div class="">
                                        <div class="">
                                           
                                           
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="jobs.html" class="nav-link">Jobs</a>
                            </li>
                            <li class="nav-item">
                                <a href="" class="nav-link">Blog</a>
                            </li>
                            <li class="nav-item">
                                <a href="" class="nav-link">Contact</a>
                            </li>
                        </ul>
                    </div>
                    <div class="offcanvas-header border-top">
                        <a href="https://themes.getbootstrap.com/product/silicon-business-technology-template-ui-kit/" class="btn btn-primary w-100" target="_blank" rel="noopener">
                <i class="bx bx-cart fs-4 lh-1 me-1"></i>
                &nbsp;Marque uma Meet
              </a>
                    </div>
                </div>
                <div class="form-check form-switch mode-switch pe-lg-1 ms-auto me-4" data-bs-toggle="mode">
                    <input type="checkbox" class="form-check-input" id="theme-mode">
                    <label class="form-check-label d-none d-sm-block" for="theme-mode">Light</label>
                    <label class="form-check-label d-none d-sm-block" for="theme-mode">Dark</label>
                </div>
                <button type="button" class="navbar-toggler" data-bs-toggle="offcanvas" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
                <a href="https://themes.getbootstrap.com/product/silicon-business-technology-template-ui-kit/" class="btn btn-primary btn-sm fs-sm rounded d-none d-lg-inline-flex" target="_blank" rel="noopener">
            <i class="bx bx-cart fs-5 lh-1 me-1"></i>
            &nbsp;Marque uma Meet
          </a>
            </div>
        </header>


        <!-- Breadcrumb -->
        <nav class="container py-4 mb-lg-2" aria-label="breadcrumb">
            <ol class="breadcrumb pt-lg-3 mb-0">
                <li class="breadcrumb-item">
                    <a href="index.html"><i class="bx bx-home-alt fs-lg me-1"></i>Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Services </li>
            </ol>
        </nav>

        <!-- Page title -->
        <h1 class="container pb-4 mt-n1 mt-lg-0">Services </h1>


        <!-- Service -->
        <section class="container mb-md-3 mb-lg-5 pb-5">
            <div class="row">
                <div class="col-md-6 pb-2 pb-md-0 mb-4 mb-md-0">
                    <div class="pe-lg-5">
                        <img src="assets-service/img/services/Design sem nome.jpg" class="rounded-3" alt="Image">
                    </div>
                </div>
                <div class="col-md-6">
                    <h2 class="h3 mb-sm-4">Consulting Recruitment Services</h2>
                    <p class="d-md-none d-xl-block pb-2 pb-md-3 mb-3">We offer a range of recruitment services to help you find the right talent for your organization. Our team of experts can assist you with every stage of the recruitment process, from identifying and sourcing candidates, to screening and interviewing, to negotiating job offers.</p>
                    <div class="border rounded-3 mb-4 mb-lg-5">
                        <div class="row row-cols-1 row-cols-sm-2 g-0">
                            <div class="col d-flex align-items-center border-end-sm border-bottom p-3">
                                <img src="assets-service/img/services/icons/1.svg" width="48" alt="Icon">
                                <div class="ps-2 ms-1">
                                    <h3 class="h6 mb-0">Talent sourcing</h3>
                                    <p class="fs-xs mb-0">Our team uses a variety of tools and resources to identify top talent in your industry.</p>
                                </div>
                            </div>
                            <div class="col d-flex align-items-center border-bottom p-3">
                                <img src="assets-service/img/services/icons/marketing.svg" width="48" alt="Icon">
                                <div class="ps-2 ms-1">
                                    <h3 class="h6 mb-0">Candidate screening</h3>
                                    <p class="fs-xs mb-0">We thoroughly screen and evaluate candidates to ensure they are a good fit for your organization.</p>
                                </div>
                            </div>
                            <div class="col d-flex align-items-center border-end-sm p-3">
                                <img src="assets-service/img/services/icons/2.svg" width="48" alt="Icon">
                                <div class="ps-2 ms-1">
                                    <h3 class="h6 mb-0">Inter &amp; viewing</h3>
                                    <p class="fs-xs mb-0">Our team conducts in-depth interviews to assess candidates' skills and qualifications.</p>
                                </div>
                            </div>
                            <hr class="d-sm-none">
                            <div class="col d-flex align-items-center p-3">
                                <img src="assets-service/img/services/icons/3.svg" width="48" alt="Icon">
                                <div class="ps-2 ms-1">
                                    <h3 class="h6 mb-0">Job  &amp; offers</h3>
                                    <p class="fs-xs mb-0">We assist with negotiating job offers and ensuring a smooth onboarding process for new hires.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex flex-column flex-sm-row">
                        <a href="#" class="btn btn-primary mb-3 mb-sm-0 me-sm-3">Request services</a>
                        <a href="#" class="btn btn-outline-primary">
                Learn more
                <i class="bx bx-right-arrow-alt fs-xl ms-2 me-n1"></i>
              </a>
                    </div>
                </div>
            </div>
        </section>

        <section class="container pt-2 pt-lg-3 mb-md-3 mb-lg-5 pb-5">
            <div class="row">
                <div class="col-md-6 order-md-2 pb-2 pb-md-0 mb-4 mb-md-0">
                    <div class="ps-lg-5">
                        <img src="assets-service/img/services/1.jpg" class="rounded-3" alt="Image">
                    </div>
                </div>
                <div class="col-md-6 ordr-md-1">
                    <h2 class="h3 mb-sm-4">Global Recruitment Services</h2>
<ul class="list-unstyled d-md-none d-xl-block pb-2 pb-md-3 mb-3">
    <li class="d-flex align-items-center mb-2">
        <i class="bx bx-check lead text-primary me-2"></i> At Global Recruitment Services, we specialize in hiring top talent across industries and sectors, with a global reach.
    </li>
    <li class="d-flex align-items-center mb-2">
        <i class="bx bx-check lead text-primary me-2"></i> Our tailored recruitment solutions cater to businesses of all sizes, regardless of their location.
    </li>
    <li class="d-flex align-items-center">
        <i class="bx bx-check lead text-primary me-2"></i> We employ an efficient and streamlined hiring process that saves you time and money.
    </li>
</ul>
<div class="border rounded-3 mb-4 mb-lg-5">
    <div class="row row-cols-1 row-cols-sm-2 g-0">
        <div class="col d-flex align-items-center border-end-sm border-bottom p-3">
            <img src="assets-service/img/services/icons/4.svg" width="48" alt="Icon">
            <div class="ps-2 ms-1">
                <h3 class="h6 mb-0">Global Recruitment</h3>
                <p class="fs-xs mb-0">Our team specializes in international recruitment, hiring top talent from all over the world.</p>
            </div>
        </div>
        <div class="col d-flex align-items-center border-bottom p-3">
            <img src="assets-service/img/services/icons/5.svg" width="48" alt="Icon">
            <div class="ps-2 ms-1">
                <h3 class="h6 mb-0">Varieties of professionals.
                </h3>
                <p class="fs-xs mb-0">We recruit the best talent from all sectors, including IT, customer service, receptionists, and more.</p>
            </div>
        </div>
        <div class="col d-flex align-items-center border-end-sm p-3">
            <img src="assets-service/img/services/icons/6.svg" width="48" alt="Icon">
            <div class="ps-2 ms-1">
                <h3 class="h6 mb-0">Ongoing Support</h3>
                <p class="fs-xs mb-0">After hiring, we provide ongoing support, including performance monitoring, time management, and frequent training and development sessions.</p>
            </div>
        </div>
    </div>
</div>
                    
                    <div class="d-flex flex-column flex-sm-row">
                        <a href="#" class="btn btn-primary mb-3 mb-sm-0 me-sm-3">Get in touch</a>
                        <a href="#" class="btn btn-outline-primary">
                            Learn more
                            <i class="bx bx-right-arrow-alt fs-xl ms-2 me-n1"></i>
                        </a>
                    </div>
                </div>
            </div>
        </section>


        <!-- Service -->
        <section class="container pt-2 pt-lg-3 mb-md-3 mb-lg-5 pb-5">
            <div class="row">
                <div class="col-md-6 pb-2 pb-md-0 mb-4 mb-md-0">
                    <div class="pe-lg-5">
                        <img src="assets-service/img/services/5.jpg" class="rounded-3" alt="Image">
                    </div>
                </div>
                <div class="col-md-6">
                    <h2 class="h3 mb-sm-4">Departments</h2>
                    <p class="d-md-none d-xl-block pb-2 pb-md-3 mb-3">Department teams are essential for a company's success as they allow activities to be divided according to each member's expertise, investing in specialized professionals to deliver better results to our clients.</p>
                    <div class="border rounded-3 mb-4 mb-lg-5">
                        <div class="row row-cols-1 row-cols-sm-2 g-0">
                            <div class="col d-flex align-items-center border-end-sm border-bottom p-3">
                                <img src="assets-service/img/services/icons/7.svg" width="48" alt="Icon">
                                <div class="ps-2 ms-1">
                                    <h3 class="h6 mb-0">Operations &amp; Technology</h3>
                                    <p class="fs-xs mb-0">Desenvolvimento e Analise de requisitos</p>
                                </div>
                            </div>
                            <div class="col d-flex align-items-center border-bottom p-3">
                                <img src="assets-service/img/services/icons/8.svg" width="48" alt="Icon">
                                <div class="ps-2 ms-1">
                                    <h3 class="h6 mb-0">Commercial</h3>
                                    <p class="fs-xs mb-0">Relacionamento com os clientes e Treinamentos</p>
                                </div>
                            </div>
                            <div class="col d-flex align-items-center border-end-sm p-3">
                                <img src="assets-service/img/services/icons/9.svg" width="48" alt="Icon">
                                <div class="ps-2 ms-1">
                                    <h3 class="h6 mb-0">Finance &amp; Contract</h3>
                                    <p class="fs-xs mb-0">Propostas e fechamento de contratos</p>
                                </div>
                            </div>
                            <hr class="d-sm-none">
                            <div class="col d-flex align-items-center p-3">
                                <img src="assets-service/img/services/icons/10.svg" width="48" alt="Icon">
                                <div class="ps-2 ms-1">
                                    <h3 class="h6 mb-0">Marketing</h3>
                                    <p class="fs-xs mb-0">Publicações e Redes sociais</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex flex-column flex-sm-row">
                        <a href="#" class="btn btn-primary mb-3 mb-sm-0 me-sm-3">Send request</a>
                        <a href="#" class="btn btn-outline-primary">
                Learn more
                <i class="bx bx-right-arrow-alt fs-xl ms-2 me-n1"></i>
              </a>
                    </div>
                </div>
            </div>
        </section>


        <!-- Industries -->
        <section class="container pt-2 pt-lg-0 pb-5 mb-md-4 mb-lg-5">
            <h2 class="h1 text-center pb-3 pb-lg-4">Competitive Advantage</h2>

        <!-- Nav tabs -->
        <ul class="nav nav-tabs flex-nowrap justify-content-lg-center overflow-auto pb-2 mb-3 mb-lg-4" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link text-nowrap active" id="education-tab" data-bs-toggle="tab" data-bs-target="#education" type="button" role="tab" aria-controls="education" aria-selected="true">
          <i class="bx bxs-graduation fs-xl opacity-60 me-2"></i>
          Artificial Intelligence
        </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-nowrap" id="ecommerce-tab" data-bs-toggle="tab" data-bs-target="#ecommerce" type="button" role="tab" aria-controls="ecommerce" aria-selected="false">
          <i class="bx bx-cart-alt fs-lg opacity-60 me-2"></i>
          Job Portal
        </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-nowrap" id="sports-tab" data-bs-toggle="tab" data-bs-target="#sports" type="button" role="tab" aria-controls="sports" aria-selected="false">
          <i class="bx bx-run fs-xl opacity-60 me-2"></i>
          Candidate Experience
        </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-nowrap" id="construction-tab" data-bs-toggle="tab" data-bs-target="#construction" type="button" role="tab" aria-controls="construction" aria-selected="false">
          <i class="bx bx-paint-roll fs-lg opacity-60 me-2"></i>
          Global Talents
        </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-nowrap" id="medicine-tab" data-bs-toggle="tab" data-bs-target="#medicine" type="button" role="tab" aria-controls="medicine" aria-selected="false">
          <i class="bx bx-plus-medical fs-bse opacity-60 me-2"></i>
          Data Analysis
        </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link text-nowrap" id="real-estate-tab" data-bs-toggle="tab" data-bs-target="#real-estate" type="button" role="tab" aria-controls="real-estate" aria-selected="false">
          <i class="bx bx-buildings fs-lg opacity-60 me-2"></i>
          Support and Training
        </button>
            </li>
           
        </ul>

            <!-- Tab panes -->
            <div class="tab-content bg-secondary rounded-3 py-4">

               <!-- AI -->
<div class="tab-pane fade show active" id="education" role="tabpanel" aria-labelledby="education-tab">
    <div class="row align-items-center pt-3 pt-sm-4 pt-md-0 px-3 px-sm-4 px-lg-0">
        <div class="col-lg-4 col-md-5 offset-lg-1 text-center text-md-start">
            <h3 class="mb-lg-4">Artificial Intelligence</h3>
            <p>Utilizing AI algorithms and tools to optimize recruitment processes and ensure more accurate and efficient candidate selection.</p>
        </div>
        <div class="col-lg-6 col-md-7 mt-2 mb-3 mt-md-3">
            <img src="assets-service/img/services/inteligencia-artificial.jpeg" class="d-block rounded-3 my-lg-2 mx-auto me-md-0" width="564" alt="Image">
        </div>
    </div>
</div>
<!-- Job Portal -->
<div class="tab-pane fade" id="ecommerce" role="tabpanel" aria-labelledby="ecommerce-tab">
    <div class="row align-items-center pt-3 pt-sm-4 pt-md-0 px-3 px-sm-4 px-lg-0">
        <div class="col-lg-4 col-md-5 offset-lg-1 text-center text-md-start">
            <h3 class="mb-lg-4">Recruitment Platform</h3>
            <p>An online platform that offers an easy-to-use interface for candidates and employers, allowing both to connect and conduct virtual interviews, skills tests, manage resumes, among other functionalities.</p>
        </div>
        <div class="col-lg-6 col-md-7 mt-2 mb-3 mt-md-3">
            <img src="assets-service/img/services/industries/ecommerce.jpg" class="d-block rounded-3 my-lg-2 mx-auto me-md-0" width="564" alt="Image">
        </div>
    </div>
</div>
                <!-- Sports -->

            <div class="tab-pane fade" id="sports" role="tabpanel" aria-labelledby="sports-tab">
                <div class="row align-items-center pt-3 pt-sm-4 pt-md-0 px-3 px-sm-4 px-lg-0">
                    <div class="col-lg-4 col-md-5 offset-lg-1 text-center text-md-start">
                        <h3 class="mb-lg-4">Candidate Experience Focus</h3>
                        <p>Offering an easy and enjoyable application experience with the personalization of the selection process according to the candidate's needs, from submitting a resume to the hiring process.</p>
                    </div>
                    <div class="col-lg-6 col-md-7 mt-2 mb-3 mt-md-3">
                        <img src="assets-service/img/services/7.png" class="d-block rounded-3 my-lg-2 mx-auto me-md-0" width="564" alt="Image">
                    </div>
                </div>
            </div>

            <!-- Construction -->
            <div class="tab-pane fade" id="construction" role="tabpanel" aria-labelledby="construction-tab">
                <div class="row align-items-center pt-3 pt-sm-4 pt-md-0 px-3 px-sm-4 px-lg-0">
                    <div class="col-lg-4 col-md-5 offset-lg-1 text-center text-md-start">
                        <h3 class="mb-lg-4">Access to Global Talent</h3>
                        <p>A global database of talented candidates that allows companies to access professionals from around the world, regardless of geographic location.</p>
                    </div>
                    <div class="col-lg-6 col-md-7 mt-2 mb-3 mt-md-3">
                        <img src="assets-service/img/services/8.png" class="d-block rounded-3 my-lg-2 mx-auto me-md-0" width="564" alt="Image">
                    </div>
                </div>
            </div>

            <!-- Medicine -->
            <div class="tab-pane fade" id="medicine" role="tabpanel" aria-labelledby="medicine-tab">
                <div class="row align-items-center pt-3 pt-sm-4 pt-md-0 px-3 px-sm-4 px-lg-0">
                    <div class="col-lg-4 col-md-5 offset-lg-1 text-center text-md-start">
                        <h3 class="mb-lg-4">Data Analysis</h3>
                        <p>Using data and analytics to better understand market trends and improve selection and recruitment processes.</p>
                    </div>
                    <div class="col-lg-6 col-md-7 mt-2 mb-3 mt-md-3">
                        <img src="assets-service/img/services/9.png" class="d-block rounded-3 my-lg-2 mx-auto me-md-0" width="564" alt="Image">
                    </div>
                </div>
            </div>

                <!-- Real Estate -->

            <div class="tab-pane fade" id="real-estate" role="tabpanel" aria-labelledby="real-estate-tab">
                <div class="row align-items-center pt-3 pt-sm-4 pt-md-0 px-3 px-sm-4 px-lg-0">
                    <div class="col-lg-4 col-md-5 offset-lg-1 text-center text-md-start">
                        <h3 class="mb-lg-4">Suporte e Treinamento</h3>
                        <p>Oferecer suporte e treinamento aos clientes na utilização das ferramentas e tecnologias disponíveis, a fim de otimizar os resultados.</p>
                    </div>
                    <div class="col-lg-6 col-md-7 mt-2 mb-3 mt-md-3">
                        <img src="assets-service/img/services/10.jpg" class="d-block rounded-3 my-lg-2 mx-auto me-md-0" width="564" alt="Imagem">
                    </div>
                </div>
            </div>

               
            </div>
        </section>


        <!-- Contact form -->
        <section class="position-relative pt-2 pt-lg-0 pb-5">
            <div class="container position-relative zindex-5 pb-2 pb-md-4 pb-lg-5">
                <div class="row justify-content-center text-center pt-xl-2 pb-4 mb-1 mb-lg-3">
                    <div class="col-xl-6 col-lg-7 col-md-8 col-sm-11">
                        <h2 class="mb-4">Let's Change the Game Together</h2>
                        <p class="text-muted mb-0">Like what you have seen? Let’s get started. Just fill in a few details and we will get in touch as soon as possible.</p>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-10">
                        <form class="row needs-validation" novalidate>
                            <div class="col-sm-6 mb-4">
                                <label for="fn" class="form-label">First name</label>
                                <input type="text" id="fn" class="form-control" required>
                                <div class="invalid-feedback">Please, enter your first name!</div>
                            </div>
                            <div class="col-sm-6 mb-4">
                                <label for="ln" class="form-label">Last name</label>
                                <input type="text" id="ln" class="form-control" required>
                                <div class="invalid-feedback">Please, enter your last name!</div>
                            </div>
                            <div class="col-sm-6 mb-4">
                                <label for="email" class="form-label">Email address</label>
                                <input type="email" id="email" class="form-control" required>
                                <div class="invalid-feedback">Please, provide a valid email address!</div>
                            </div>
                            <div class="col-sm-6 mb-4">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" id="phone" class="form-control" data-format='{"numericOnly": true, "delimiters": ["+1 ", " ", " "], "blocks": [0, 3, 3, 2]}' placeholder="+1 ___ ___ __">
                            </div>
                            <div class="col-sm-6 mb-4">
                                <label for="city" class="form-label">City</label>
                                <select id="city" class="form-select" required>
                    <option value="" disabled selected>Choose city</option>
                    <option value="Boston">Boston</option>
                    <option value="Chicago">Chicago</option>
                    <option value="Los Angeles">Los Angeles</option>
                    <option value="Miami">Miami</option>
                    <option value="New York">New York</option>
                    <option value="Philadelphia">Philadelphia</option>
                  </select>
                                <div class="invalid-feedback">Please, choose your city!</div>
                            </div>
                            <div class="col-sm-6 mb-4">
                                <label for="company" class="form-label">Your company</label>
                                <input type="text" id="company" class="form-control">
                            </div>
                            <div class="col-sm-6 mb-4">
                                <label for="position" class="form-label">Your position</label>
                                <select id="position" class="form-select">
                    <option value="Owner">Owner</option>
                    <option value="CEO">CEO</option>
                    <option value="Manager">Manager</option>
                    <option value="Accountant">Accountant</option>
                  </select>
                            </div>
                            <div class="col-sm-6 mb-4">
                                <label for="people" class="form-label">People in company</label>
                                <select id="people" class="form-select">
                    <option value="0-10">0-10</option>
                    <option value="10-25">10-25</option>
                    <option value="25-50">25-50</option>
                    <option value="50-100">50-100</option>
                  </select>
                            </div>
                            <div class="col-12 mb-4">
                                <label for="message" class="form-label">Message</label>
                                <textarea id="message" class="form-control" rows="4" required></textarea>
                                <div class="invalid-feedback">Please, enter your message!</div>
                            </div>
                            <div class="col-12 text-center pt-2 pt-md-3 pt-lg-4">
                                <button type="submit" class="btn btn-primary shadow-primary btn-lg">Send a request</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- BG shape -->
            <div class="position-absolute end-0 bottom-0 text-primary">
                <svg width="469" height="343" viewBox="0 0 469 343" fill="none" xmlns="http://www.w3.org/2000/svg"><path opacity="0.08" fill-rule="evenodd" clip-rule="evenodd" d="M273.631 680.872C442.436 768.853 639.315 708.216 717.593 558.212C795.871 408.208 732.941 212.157 564.137 124.176C395.333 36.195 198.453 96.8326 120.175 246.836C41.8972 396.84 104.827 592.891 273.631 680.872ZM236.335 752.344C440.804 858.914 688.289 788.686 789.109 595.486C889.928 402.286 805.903 159.274 601.433 52.7043C396.964 -53.8654 149.479 16.3623 48.6595 209.562C-52.1598 402.762 31.8652 645.774 236.335 752.344Z" fill="currentColor"/><path opacity="0.08" fill-rule="evenodd" clip-rule="evenodd" d="M298.401 633.404C434.98 704.59 598.31 656.971 664.332 530.451C730.355 403.932 675.946 242.827 539.367 171.642C402.787 100.457 239.458 148.076 173.435 274.595C107.413 401.114 161.822 562.219 298.401 633.404ZM288.455 652.464C434.545 728.606 611.369 678.429 683.403 540.391C755.437 402.353 695.402 228.725 549.312 152.583C403.222 76.4404 226.398 126.617 154.365 264.655C82.331 402.693 142.365 576.321 288.455 652.464Z" fill="currentColor"/></svg>
            </div>
        </section>
    </main>


    <!-- Footer -->
    <footer class="footer dark-mode bg-dark border-top border-light pt-5 pb-4 pb-lg-5">
        <div class="container pt-lg-4">
            <div class="row pb-5">
                <div class="col-lg-4 col-md-6">
                    <div class="navbar-brand text-dark p-0 me-0 mb-3 mb-lg-4">
                        <img src="assets-service/img/logo.svg" width="47" alt="Gree"> Hire Gree
                    </div>
                    <p class="fs-sm text-light opacity-70 pb-lg-3 mb-4">Proin ipsum pharetra, senectus eget scelerisque varius pretium platea velit. Lacus, eget eu vitae nullam proin turpis etiam mi sit. Non feugiat feugiat egestas nulla nec. Arcu tempus, eget elementum dolor ullamcorper sodales ultrices
                        eros.</p>
                    <form class="needs-validation" novalidate>
                        <label for="subscr-email" class="form-label">Subscribe to our newsletter</label>
                        <div class="input-group">
                            <input type="email" id="subscr-email" class="form-control rounded-start ps-5" placeholder="Your email" required>
                            <i class="bx bx-envelope fs-lg text-muted position-absolute top-50 start-0 translate-middle-y ms-3 zindex-5"></i>
                            <div class="invalid-tooltip position-absolute top-100 start-0">Please provide a valid email address.</div>
                            <button type="submit" class="btn btn-primary">Subscribe</button>
                        </div>
                    </form>
                </div>
                <div class="col-xl-6 col-lg-7 col-md-5 offset-xl-2 offset-md-1 pt-4 pt-md-1 pt-lg-0">
                    <div id="footer-links" class="row">
                        <div class="col-lg-4">
                            <h6 class="mb-2">
                                <a href="#useful-links" class="d-block text-dark dropdown-toggle d-lg-none py-2" data-bs-toggle="collapse">Useful Links</a>
                            </h6>
                            <div id="useful-links" class="collapse d-lg-block" data-bs-parent="#footer-links">
                                <ul class="nav flex-column pb-lg-1 mb-lg-3">
                                    <li class="nav-item"><a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Home</a></li>
                                    <li class="nav-item"><a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">About</a></li>
                                    <li class="nav-item"><a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Services</a></li>
                                    <li class="nav-item"><a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Our Clients</a></li>
                                    <li class="nav-item"><a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">News</a></li>
                                </ul>
                                <ul class="nav flex-column mb-2 mb-lg-0">
                                    <li class="nav-item"><a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Terms &amp; Conditions</a></li>
                                    <li class="nav-item"><a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-3">
                            <h6 class="mb-2">
                                <a href="#social-links" class="d-block text-dark dropdown-toggle d-lg-none py-2" data-bs-toggle="collapse">Socials</a>
                            </h6>
                            <div id="social-links" class="collapse d-lg-block" data-bs-parent="#footer-links">
                                <ul class="nav flex-column mb-2 mb-lg-0">
                                    <li class="nav-item"><a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Facebook</a></li>
                                    <li class="nav-item"><a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">LinkedIn</a></li>
                                    <li class="nav-item"><a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Twitter</a></li>
                                    <li class="nav-item"><a href="#" class="nav-link d-inline-block px-0 pt-1 pb-2">Instagram</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-5 pt-2 pt-lg-0">
                            <h6 class="mb-2">Contact Us</h6>
                            <a href="mailto:email@example.com" class="fw-medium">email@example.com</a>
                        </div>
                    </div>
                </div>
            </div>
            <p class="nav d-block fs-xs text-center text-md-start pb-2 pb-lg-0 mb-0">
                <span class="text-light opacity-50">&copy; All rights reserved. Made by </span>
                <a class="nav-link d-inline-block p-0" href="https://createx.studio/" target="_blank" rel="noopener">Createx Studio</a>
            </p>
        </div>
    </footer>


    <!-- Back to top button -->
    <a href="#top" class="btn-scroll-top" data-scroll>
      <span class="btn-scroll-top-tooltip text-muted fs-sm me-2">Top</span>
      <i class="btn-scroll-top-icon bx bx-chevron-up"></i>
    </a>


    <!-- Vendor Scripts -->
    <script src="assets-service/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets-service/vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js"></script>
    <script src="assets-service/vendor/cleave.js/dist/cleave.min.js"></script>

    <!-- Main Theme Script -->
    <script src="assets-service/js/theme.min.js"></script>
</body>

</html>