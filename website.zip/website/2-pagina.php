<!DOCTYPE html>
<html lang="en">

<head>

    <!-- metas -->
    <meta charset="utf-8">
    <meta name="author" content="Chitrakoot Web" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="keywords" content="Job Portal HTML Template" />
    <meta name="description" content="Job Board - Job Portal HTML Template" />

    <!-- title  -->
    <title>Hire Gree - Jobs</title>
 <!-- Additional CSS Files -->
 <link href="assets/css/main.css" rel="stylesheet">
 <link href="assets-oficial/images/17.png" rel="icon">

 <link rel="stylesheet" href="assets-oficial/css/fontawesome.css">
 <link rel="stylesheet" href="assets-oficial/css/templatemo-grad-school.css">
 <link rel="stylesheet" href="assets-oficial/css/owl.css">
 <link rel="stylesheet" href="assets-oficial/css/lightbox.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="img/logos/favicon.png" />
    <link rel="apple-touch-icon" href="img/logos/apple-touch-icon-57x57.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="img/logos/apple-touch-icon-72x72.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="img/logos/apple-touch-icon-114x114.png" />

    <!-- plugins -->
    <link rel="stylesheet" href="assets-vagas/css/plugins.css" />

    <!-- search css -->
    <link rel="stylesheet" href="assets-vagas/search/search.css" />

    <!-- quform css -->
    <link rel="stylesheet" href="assets-vagas/quform/css/base.css">

    <!-- core style css -->
    <link href="assets-vagas/css/styles.css" rel="stylesheet" />

<!-- plugins PC -->
<link rel="stylesheet" href="assets-vagas/css/plugins_pc.css" />

<!-- search css -->
<link rel="stylesheet" href="assets-vagas/search/search_pc.css" />

<!-- quform css -->
<link rel="stylesheet" href="assets-vagas/quform/css/base_pc.css">

<!-- core style css -->
<link href="assets-vagas/css/styles_pc.css" rel="stylesheet" />
</head>

<body>

    <!-- PAGE LOADING
    ================================================== -->
    <div id="preloader"></div>

    <!-- MAIN WRAPPER
    ================================================== -->
    <div class="main-wrapper">

        <!-- HEADER
        ================================================== -->
       





               


<!--começo - nosso processo-->

 
        <!-- JOB GRID 1
        ================================================== -->
        <section>
            <div class="container">
                <div class="row mb-2-2">
                    <div class="col-lg-12">
                   
                <div class="row mt-n1-9">
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="card border-color-extra-light-gray h-100 border-radius-5">
                            <div class="card-body p-1-6 p-xl-1-9">
                                <h4 class="h5 mb-4"><a href="job-details.html">Application Developer</a></h4>
                                <div class="d-flex mb-3">
                                    <div class="flex-shrink-0">
                                        <img src="assets-vagas/img/avatar/avatar-01.jpg" class="border-radius-50 w-40px" alt="...">
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-0">Michelle Herz</h6>
                                        <span class="text-muted display-31">Nov 18, 2021</span>
                                    </div>
                                </div>
                                <h5 class="text-primary mb-3">5500$ <span class="text-muted display-31">/ Month</span> </h5>
                                <div class="mb-4">
                                    <span class="display-30 me-2"><i class="fas fa-map-marker-alt pe-2"></i>Canada, USA</span>
                                    <span class="display-30"><i class="far fa-clock pe-2"></i>Full Time</span>
                                </div>
                                <a class="butn butn-md radius" href="mailto:seuemailaqui@provedor.com?subject=Assunto do e-mail aqui&body=Corpo do e-mail aqui">Apply Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="card border-color-extra-light-gray h-100 border-radius-5">
                            <div class="card-body p-1-6 p-xl-1-9">
                                <h4 class="h5 mb-4"><a href="job-details.html">Marketing Manager</a></h4>
                                <div class="d-flex mb-3">
                                    <div class="flex-shrink-0">
                                        <img src="assets-vagas/img/avatar/avatar-02.jpg" class="border-radius-50 w-40px" alt="...">
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-0">Kurak Torath</h6>
                                        <span class="text-muted display-31">Nov 15, 2021</span>
                                    </div>
                                </div>
                                <h5 class="text-primary mb-3">6200$ <span class="text-muted display-31">/ Month</span> </h5>
                                <div class="mb-4">
                                    <span class="display-30 me-2"><i class="fas fa-map-marker-alt pe-2"></i>London, Uk</span>
                                    <span class="display-30"><i class="far fa-clock pe-2"></i>Full Time</span>
                                </div>
                                <a class="butn butn-md radius" href="mailto:seuemailaqui@provedor.com?subject=Assunto do e-mail aqui&body=Corpo do e-mail aqui">Apply Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="card border-color-extra-light-gray h-100 border-radius-5">
                            <div class="card-body p-1-6 p-xl-1-9">
                                <h4 class="h5 mb-4"><a href="job-details.html">Graphics Design Expert</a></h4>
                                <div class="d-flex mb-3">
                                    <div class="flex-shrink-0">
                                        <img src="assets-vagas/img/avatar/avatar-03.jpg" class="border-radius-50 w-40px" alt="...">
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-0">Lea Dreher</h6>
                                        <span class="text-muted display-31">Nov 13, 2021</span>
                                    </div>
                                </div>
                                <h5 class="text-primary mb-3">3200$ <span class="text-muted display-31">/ Month</span> </h5>
                                <div class="mb-4">
                                    <span class="display-30 me-2"><i class="fas fa-map-marker-alt pe-2"></i>Montreal, US</span>
                                    <span class="display-30"><i class="far fa-clock pe-2"></i>Part Time</span>
                                </div>
                                <a class="butn butn-md radius" href="mailto:seuemailaqui@provedor.com?subject=Assunto do e-mail aqui&body=Corpo do e-mail aqui">Apply Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="card border-color-extra-light-gray h-100 border-radius-5">
                            <div class="card-body p-1-6 p-xl-1-9">
                                <h4 class="h5 mb-4"><a href="job-details.html">Senior Software Engineer</a></h4>
                                <div class="d-flex mb-3">
                                    <div class="flex-shrink-0">
                                        <img src="assets-vagas/img/avatar/avatar-04.jpg" class="border-radius-50 w-40px" alt="...">
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-0">Clovis Devoe</h6>
                                        <span class="text-muted display-31">Nov 12, 2021</span>
                                    </div>
                                </div>
                                <h5 class="text-primary mb-3">4500$ <span class="text-muted display-31">/ Month</span> </h5>
                                <div class="mb-4">
                                    <span class="display-30 me-2"><i class="fas fa-map-marker-alt pe-2"></i>Delhi, India</span>
                                    <span class="display-30"><i class="far fa-clock pe-2"></i>Full Time</span>
                                </div>
                                <a class="butn butn-md radius" href="mailto:seuemailaqui@provedor.com?subject=Assunto do e-mail aqui&body=Corpo do e-mail aqui">Apply Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="card border-color-extra-light-gray h-100 border-radius-5">
                            <div class="card-body p-1-6 p-xl-1-9">
                                <h4 class="h5 mb-4"><a href="job-details.html">Health Advisor</a></h4>
                                <div class="d-flex mb-3">
                                    <div class="flex-shrink-0">
                                        <img src="assets-vagas/img/avatar/avatar-05.jpg" class="border-radius-50 w-40px" alt="...">
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-0">Aatifa Gabriel</h6>
                                        <span class="text-muted display-31">Nov 10, 2021</span>
                                    </div>
                                </div>
                                <h5 class="text-primary mb-3">2300$ <span class="text-muted display-31">/ Month</span> </h5>
                                <div class="mb-4">
                                    <span class="display-30 me-2"><i class="fas fa-map-marker-alt pe-2"></i>Paris, France</span>
                                    <span class="display-30"><i class="far fa-clock pe-2"></i>Part Time</span>
                                </div>
                                <a class="butn butn-md radius" href="mailto:seuemailaqui@provedor.com?subject=Assunto do e-mail aqui&body=Corpo do e-mail aqui">Apply Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="card border-color-extra-light-gray h-100 border-radius-5">
                            <div class="card-body p-1-6 p-xl-1-9">
                                <h4 class="h5 mb-4"><a href="job-details.html">Project Team Leader</a></h4>
                                <div class="d-flex mb-3">
                                    <div class="flex-shrink-0">
                                        <img src="assets-vagas/img/avatar/avatar-06.jpg" class="border-radius-50 w-40px" alt="...">
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-0">Juhana Hasu</h6>
                                        <span class="text-muted display-31">Nov 07, 2021</span>
                                    </div>
                                </div>
                                <h5 class="text-primary mb-3">2500$ <span class="text-muted display-31">/ Month</span> </h5>
                                <div class="mb-4">
                                    <span class="display-30 me-2"><i class="fas fa-map-marker-alt pe-2"></i>Dhaka, BD</span>
                                    <span class="display-30"><i class="far fa-clock pe-2"></i>Full Time</span>
                                </div>
                                <a class="butn butn-md radius" href="mailto:seuemailaqui@provedor.com?subject=Assunto do e-mail aqui&body=Corpo do e-mail aqui">Apply Now</a>

                             
                    </div>
                </div>
        </section>

      <!-- FOOTER
        ================================================== -->
        <footer class="pt-0">
            <div class="container border-bottom border-color-light-white py-2-5 py-md-6 mb-6 mb-md-8 mb-lg-10">
                <div class="row justify-content-center align-items-center mt-n1-9">
                    <div class="col-xl-6 mt-1-9">
                          
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row mt-n2-6">
                    <div class="col-sm-6 col-lg-3 mt-2-6">
                        <h3 class="h5 mb-1-6 mb-lg-1-9 text-white">Contact Us</h3>
                        <p class="mb-1-6 text-white opacity9">Advertise your jobs to hundreds of thousands of monthly customers and seek 15.8 million CV in our database.</p>
                        <ul class="contact-list">
                            <li class="d-flex"><span class="fa fa-home pe-3 text-white"></span><a href="#!">66 Guild Street 512B, Great North Town.</a></li>
                            <li class="d-flex"><span class="fa fa-phone-alt pe-3 text-white"></span><a href="#!">(+44) 123 456 789</a></li>
                            <li class="d-flex"><span class="fa fa-envelope pe-3 text-white"></span><a href="#!">info@example.com</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-lg-2 mt-2-6">
                        <div class="ps-sm-1-9">
                            <h3 class="h5 mb-1-6 mb-lg-1-9 text-white">Information</h3>
                            <ul class="footer-list-style1">
                                <li><a href="aboutus.html">About us</a></li>
                                <li><a href="blog-grid.html">Blog</a></li>
                                <li><a href="how-it-works.html">Our Process</a></li>
                                <li><a href="pricing-plans.html">Our Pricing</a></li>
                                <li><a href="contact-us.html">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-2 mt-2-6">
                        <div class="ps-lg-1-9">
                            <h3 class="h5 mb-1-6 mb-lg-1-9 text-white">Candidates</h3>
                            <ul class="footer-list-style1">
                                <li><a href="candidate-applied-job.html">Applied Job</a></li>
                                <li><a href="candidate-cv-manager.html">CV Manager</a></li>
                                <li><a href="candidate-shortlisted-jobs.html">Shortlisted Jobs</a></li>
                                <li><a href="candidate-job-alerts.html">Job Alerts</a></li>
                                <li><a href="candidate-dashboard.html">Dashboard</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-2 mt-2-6">
                        <div class="ps-sm-1-9 ps-lg-2-2 ps-xl-2-5">
                            <h3 class="h5 mb-1-6 mb-lg-1-9 text-white">Employers</h3>
                            <ul class="footer-list-style1">
                                <li><a href="employer-packages.html">Job Packages</a></li>
                                <li><a href="employer-company-profile.html">Company Profile</a></li>
                                <li><a href="employer-manage-job.html">Manage Job</a></li>
                                <li><a href="employer-resume-alerts.html">Resume Alerts</a></li>
                                <li><a href="employer-post-job.html">Post a Job</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-2-6">
                        <div class="ps-lg-2-2 ps-xl-2-5">
                            <h3 class="h5 mb-1-6 mb-lg-1-9 text-white">Join Newsletter</h3>
                            <p class="text-white mb-4">Subscribe to get the latest jobs posted, candidates...</p>
                            <form class="quform newsletter-form" action="assets-service/quform/newsletter-two.php" method="post" enctype="multipart/form-data" onclick="">
                                <div class="quform-elements">
                                    <div class="row">
                                        <!-- Begin Text input element -->
                                        <div class="col-md-12">
                                            <div class="quform-element">
                                                <div class="quform-input">
                                                    <input class="form-control" id="email_address" type="text" name="email_address" placeholder="Subscribe with us" />
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Text input element -->

                                        <!-- Begin Submit button -->
                                        <div class="col-md-12">
                                            <div class="quform-submit-inner">
                                                <button class="btn btn-white text-primary m-0" type="submit"><span><i class="fas fa-paper-plane text-primary"></i></span></button>
                                            </div>
                                            <div class="quform-loading-wrap text-start"><span class="quform-loading"></span></div>
                                        </div>
                                        <!-- End Submit button -->
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bar borders-top border-color-light-white">
                <div class="container">
                    <div class="row">
                        <div class="col-md-7 text-center text-md-start mt-3 mt-md-0 order-2 order-md-1">
                            <p class="d-inline-block text-white mb-0">&copy; <span class="current-year"></span> Job Board Powered by
                                <a href="https://www.chitrakootweb.com/" target="_blank" class="text-primary white-hover">Chitrakoot Web</a>
                            </p>
                        </div>
                        <div class="col-md-5 text-center text-md-end order-1 order-md-2">
                            <p class="text-white d-inline-block mb-0 align-middle">Follow Us :</p>
                            <ul class="footer-social-style1">
                                <li>
                                    <a href="#!"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="#!"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#!"><i class="fab fa-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="#!"><i class="fab fa-linkedin-in"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>


    <!-- BUY TEMPLATE
    ================================================== -->
    <div class="buy-theme alt-font d-none d-lg-inline-block"><a href="https://wrapbootstrap.com/theme/job-board-job-portal-html-template-WB0S2FC71" target="_blank"><i class="fas fa-cart-plus"></i><span>Buy Template</span></a></div>

    <div class="all-demo alt-font d-none d-lg-inline-block"><a href="https://www.chitrakootweb.com/contact.html" target="_blank"><i class="far fa-envelope"></i><span>Quick Question?</span></a></div>

    <!-- start scroll to top -->
    <a href="#!" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
    <!-- end scroll to top -->

    <!-- all js include start -->

    
    <!-- all js include end -->
    <div class="buy-theme alt-font d-none d-lg-inline-block"><a href="https://wrapbootstrap.com/theme/job-board-job-portal-html-template-WB0S2FC71" target="_blank"><i class="fas fa-cart-plus"></i><span>Buy Template</span></a></div>

    <div class="all-demo alt-font d-none d-lg-inline-block"><a href="https://www.chitrakootweb.com/contact.html" target="_blank"><i class="far fa-envelope"></i><span>Quick Question?</span></a></div>

    <!-- start scroll to top -->
    <a href="#!" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
    <!-- end scroll to top -->

    <!-- all js include start _PC -->

    <!-- jQuery -->
    <script src="assets-vagas/js/jquery_pc.min.js"></script>

    <!-- popper js -->
    <script src="assets-vagas/js/popper_pc.min.js"></script>

    <!-- bootstrap -->
    <script src="assets-vagas/js/bootstrap_pc.min.js"></script>

    <!-- core.min.js -->
    <script src="assets-vagas/js/core_pc.min.js"></script>

    <!-- search -->
    <script src="assets-vagas/search/search_pc.js"></script>

    <!-- custom scripts -->
    <script src="assets-vagas/js/main_pc.js"></script>

    <!-- form plugins js -->
    <script src="assets-vagas/quform/js/plugins_pc.js"></script>

    <!-- form scripts js -->
    <script src="assets-vagas/quform/js/scripts_pc.js"></script>

    <!-- all js include end -->
 <!-- Bootstrap core JavaScript -->

 <script src="assets-oficial/vendor/jquery/jquery.min.js"></script>
 <script src="assets-oficialvendor/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-element-bundle.min.js"></script>

 <script src="assets-oficial/js/isotope.min.js"></script>
 <script src="assets-oficial/js/owl-carousel.js"></script>
 <script src="assets-oficial/js/lightbox.js"></script>
 <script src="assets-oficial/js/tabs.js"></script>
 <script src="assets-oficial/js/video.js"></script>
 <script src="assets-oficial/js/slick-slider.js"></script>
 <script src="assets-oficial/js/custom.js"></script>

</body>

</html>